import React from "react";
import { StyleSheet, View,Image } from "react-native";
import {TextInput, Text, Button, } from 'react-native-paper'

const Author = (state) => {
    return(
        <View style={styles.container}>

           <View style={styles.profileCard}>

            <View style={styles.ProfilePicture}>
            <Image style={styles.profileCardLogo} source={require("../assets/behzadQasim.png")}/>
            </View>

            <View style={styles.ProfileTitle}>
            <Text style={styles.ProfileTitleText}>Writer</Text>
            </View>

            <View style={styles.ProfileTitleName}>
            <Text style={styles.ProfileTitleNameText}>Behzad Qasim</Text>
            </View>

            <View style={styles.ProfileFollowFollowing}>
            <View style={styles.ProfileFollow}>
            <Text style={styles.ProfileFollowText}>Follow</Text>
            <Text style={styles.ProfileFollowText}>0</Text>
            </View>

            <View style={styles.ProfileFollowing}>
            <Text style={styles.ProfileFollowingText}>Following</Text>
            <Text style={styles.ProfileFollowText}>0</Text>
            </View>
            </View>

            
           </View>

           <View style={styles.profileContent}>

           
            
           </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 15,
        flexDirection: 'column',
        backgroundColor: 'white',
      },
      profileCard:{
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#062743',
        borderRadius: 40,
      },
      ProfilePicture:{
        padding: 10,
      },
      profileCardLogo:{
        width: 100,
        height: 100,
        borderRadius: 50,
      },
      ProfileTitle:{
        paddingTop: 40,
      },
      ProfileTitleName:{
        padding: 5,
      },
      ProfileTitleNameText:{
        fontSize: 21,
        color: '#ffffff',
        fontWeight: '700',
      },
      ProfileTitleText:{
        fontSize: 16,
        color: 'grey',
        fontWeight: '300',
      },
      ProfileFollowFollowing:{
        marginTop: 30,
        flexDirection: 'row',
      },
      ProfileFollow:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      },
      ProfileFollowText:{
        fontSize: 17,
        color: 'silver',
        fontWeight: '500',
      },
      ProfileFollowing:{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      },
      ProfileFollowingText:{
        fontSize: 17,
        color: 'silver',
        fontWeight: '500',
      },
      profileContent:{
        flex: 1,
      },
});

export default Author;