import React, { useState, useEffect } from 'react'
import { StyleSheet, View, Image, TouchableOpacity, ScrollView, Alert } from 'react-native'
import { TextInput, Text, Button } from 'react-native-paper'
import axios from 'axios'

import { useSelector, useDispatch } from 'react-redux';

const WritePost = state => {

  const userLoggedInData = useSelector((state) => { return state.user });

  const [heading, setheading] = React.useState('')
  const [postText, setpostText] = React.useState('')
  const [predictedWords, setpredictedWords] = React.useState([]);
  const [authour, setauthor] = React.useState(userLoggedInData[0]['name']);

  const [selectedCategory, setselectedCategory] = React.useState('');

  const categories = ["general", "business", "entertainment", "health", "science", "sports", "technology"];

  const predictNextWord = async () => {
    const words = postText.split(" ");
    const numberOfWords = words.length;
    if (numberOfWords >= 4) {
      console.log("Sending Data to Model ...")
      await axios.post('http://192.168.100.5:5000/predict', { 'seed_text': postText })
        .then(response => {
          setpredictedWords(response.data['next_words'])
        })
        .catch(error => {
          console.error('Error:', error);
        });
    }
  }

  const checkPlagirsm = async () => {
    const words = postText.split(" ");
    const numberOfWords = words.length;
    if (numberOfWords >= 10) {
      console.log("Sending Data to Model ...")
      await axios.post('http://192.168.100.5:5000/checkPlag', { 'article': postText, 'author': authour, 'title': heading })
        .then(response => {
          if (response.data["message"]) {
            if (response.data["message"]["message"]) {
              console.log('Response1:', response.data);
              Alert.alert("Article Pendown Successfully.", response.data["message"]["message"])
            }
            else if (response.data["message"]["plag score"]) {
              console.log('Response2:', response.data);
              const errorMessage = response.data["message"]["warning"] + ' and written by' + response.data["message"]["author"] + " and title is '" + response.data["message"]["title"];
              Alert.alert("Article Error", errorMessage)
            }
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
    }
    else {
      Alert.alert("Error", "Length is too short to check... ")
    }
  }

  const NextwordButton = props => {
    return (
      <TouchableOpacity style={{ width: 80, borderRadius: 10, backgroundColor: 'grey', paddingVertical: 10, marginHorizontal: 5 }} onPress={() => { setpostText(postText + " " + props.word) }}>
        <Text style={{ textAlign: 'center', color: '#fff', fontSize: 13 }}  >{props.word}</Text>
      </TouchableOpacity>
    )
  }

  // useEffect(() => {
  //     predictNextWord()
  // }, [postText])

  return (
    <View style={styles.container}>
      <View style={styles.heading}>
        <Text style={styles.headingText}>Pendown Your Thought</Text>
      </View>
      <View style={styles.postBody}>
        <ScrollView>
          <View style={{ flex: 3, justifyContent: 'center', alignItems: 'center', }}>
            <TextInput
              label='Enter heading of your post'
              mode='outlined'
              left
              style={styles.textInput}
              value={heading}
              onChangeText={text => setheading(text)}
            />
          </View>
          <Text style={{fontSize: 16, fontWeight: '700', paddingVertical: 5,}} >Select category</Text>
          <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingVertical: 10, }}>
            <ScrollView
              horizontal={true}
              showsHorizontalScrollIndicator={false}>
              {categories.map((value, index) => {
                return (
                  <TouchableOpacity
                    key={index}
                    style={[styles.categoriesButton, { backgroundColor: value === selectedCategory ? "#690074" : '#9B3284' }]}
                    onPress={() => { setselectedCategory(value) }}
                  >
                    <Text style={styles.text_for_categoriesButton} >{value}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
          <View style={{ flex: 6, justifyContent: 'center', alignItems: 'center', paddingVertical: 10, }}>
            <View style={{ flex: 5, width: '100%', paddingVertical: 10 }}>
              <TextInput
                label='Pendown your thought here ....'
                mode='outlined'
                numberOfLines={20}
                left
                style={[styles.textInput, { paddingVertical: 40 }]}
                value={postText}
                onChangeText={text => setpostText(text)}
                onSubmitEditing={() => { predictNextWord() }}
              />
            </View>

            {/* <TouchableOpacity style={styles.button} onPress={() => { predictNextWord() }}>
              <Text style={{ textAlign: 'center', color: 'white' }}>Predict Next Word</Text>
            </TouchableOpacity> */}
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
              <ScrollView
                horizontal={true}
                showsHorizontalScrollIndicator={false}>
                {predictedWords.map((word, index) => (
                  <NextwordButton word={word} key={Math.random()} />
                ))}

              </ScrollView>
            </View>

          </View>

          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <TouchableOpacity style={styles.button} onPress={() => { checkPlagirsm() }}>
              <Text style={{ textAlign: 'center', color: 'white' }}>Publish</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => { setpostText(""); setheading("") }}>
              <Text style={{ textAlign: 'center', color: 'white' }}>Discard</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    marginBottom: 50,
    flexDirection: 'column',
    backgroundColor: 'white',
  },
  heading: {
    flex: 0.5,
    justifyContent: "center",
    alignItems: "center"
  },
  headingText: {
    fontSize: 25,
    fontWeight: '800',
    textAlign: 'center',
  },
  postBody: {
    flex: 10,
    padding: 30,
    marginVertical: 10,
    marginHorizontal: 10,
    borderRadius: 20,
    backgroundColor: '#F4F4F4',
  },
  textInput: {
    color: 'grey',
    fontSize: 16,
    backgroundColor: '#fff',
    borderRadius: 10,
    textAlign: "left",
    width: '100%',
  },
  button: {
    backgroundColor: '#1363DF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginVertical: 20,
    marginHorizontal: 10,
    width: '100%',
    textAlign: 'center',
    borderRadius: 10,
  },
  categoriesButtonrow: {
    flexDirection: 'row',
  },
  categoriesButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginHorizontal: 5,
    borderRadius: 20,
  },
  text_for_categoriesButton: {
    color: 'white',
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center'
  },
})

export default WritePost
