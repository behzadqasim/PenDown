import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Image, Text, TouchableOpacity } from "react-native";

import AsyncStorage from '@react-native-async-storage/async-storage';

import { useDispatch, useSelector } from 'react-redux';
import { setLoggedInUser } from '../configuration/store/slice/userSlice';

const Splash = ({navigation}) => {

    const [userInfoFound, setuserInfoFound] = useState(false);
    const dispatch = useDispatch();
    const userLoggedInData = useSelector((state) => { return state.user });

    function startTheApp(){
        console.log(userLoggedInData[0])
        if(userLoggedInData[0]){
            navigation.navigate('HomeTabs');
            console.log("user found")
        }
        else{
            navigation.navigate('Login');
            console.log("user not found")
        }
    };

    useEffect(() => {
        const getLoggedInUserInfoFromDevice = async () => {
            try {
                const jsonValue = await AsyncStorage.getItem('@storage_Key')
                console.log(jsonValue);
                setuserInfoFound(true);
                dispatch(setLoggedInUser(JSON.parse(jsonValue)));
                console.log("User info : ", JSON.parse(jsonValue))
                return jsonValue != null ? JSON.parse(jsonValue) : null;
            } catch (e) {
                Alert.alert("Error", "Error in Fetching data of Logged In user from device.");
            }
        };
        getLoggedInUserInfoFromDevice();
    }, []);


    return (<View style={styles.container}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Image source={require("../assets/logo.jpg")} style={{width: 500, height: 500}} />
        </View>
        <View style={{justifyContent:'center',alignItems:'center'}}>
        <Text style={styles.logo}>PenDown</Text>
      </View>
        <View style={{ flex: 0.5, justifyContent: 'center', alignItems: 'center' }}>
            <TouchableOpacity style={styles.Button} onPress={()=>{startTheApp()}} >
                <Text style={{ color: '#fff' }} >
                    Start Now
                </Text>
            </TouchableOpacity>
        </View>
    </View>)
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    Button: {
        width: '100%',
        backgroundColor: '#303481',
        paddingHorizontal: 100,
        paddingVertical: 15,
        borderRadius: 5,
    },
    logo: {
        fontSize: 50,
        color: '#161D6F',
        letterSpacing: 1,
        fontWeight: '800',
      },
});

export default Splash;