import React from 'react'
import {StyleSheet, View, Alert} from 'react-native'
import {TextInput, Text, Button} from 'react-native-paper'

import {firebase} from "../configuration/firebase/Firebase";
import { useDispatch } from 'react-redux';
import { setLoggedInUser } from '../configuration/store/slice/userSlice';

import AsyncStorage from '@react-native-async-storage/async-storage';

const Login = ({navigation}) => {

  const dispatch = useDispatch();
  
  const [emailAddress, setemailAddress] = React.useState('')
  const [password, setpassword] = React.useState('')

  const signInNow = async () => {
    if(emailAddress == "" || password == ""){
      Alert.alert("Error","Please enter all data.")
    }
    else{
      firebase.auth().signInWithEmailAndPassword(emailAddress,password)
      .then((response)=>{
        const databaseRef = firebase.database().ref('users/' + response.user.uid);
        databaseRef.on('value', (snapshot) => {
          console.log("Logging In...");
          const userData = snapshot.val();
          const storeData = async (value) => {
            try {
              const jsonValue = JSON.stringify(value)
              //console.log(jsonValue)
              await AsyncStorage.setItem('@storage_Key', jsonValue)
              console.log("Logged in user info saved in device.");
            } catch (e) {
             Alert.alert("Error","While saving loggedin user info in the device.");
            }
          }
          storeData(userData);
          console.log(userData)
          dispatch(setLoggedInUser(userData));
          navigation.navigate('HomeTabs');
        })
      })
      .catch((error)=>{
        console.log(error);
        Alert.alert("Error",error.message)
      })
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.logoBox}>
        <Text style={styles.logo}>PenDown</Text>
      </View>
      <View style={styles.loginBody}>
        <View style={styles.loginBody_Item}>
          <Text style={styles.loginHeadingText}>Login to your Account</Text>
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Email Address'
            mode='outlined'
            left
            style={styles.textInput}
            value={emailAddress}
            onChangeText={text => setemailAddress(text)}
          />
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Password'
            mode='outlined'
            left
            style={styles.textInput}
            value={password}
            onChangeText={text => setpassword(text)}
          />
        </View>

        <View style={styles.loginBody_Item}>
          <Button
          icon="pen"
          mode='contained'
            style={styles.Button}
            onPress={() => {signInNow()}}>
            <Text style={{color: 'white'}}>Sign In</Text>
          </Button>
        </View>
      </View>
      <View style={styles.extraOption}>
      <View style={styles.loginBody_Item} >
          <Text style={styles.extraOption_Text}>Don't have an account? <Text style={{color: '#303481'}} onPress={()=>{navigation.navigate("Register")}}>Sign Up</Text></Text>
        </View>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  logoBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    fontSize: 50,
    color: '#161D6F',
    letterSpacing: 1,
    fontWeight: '800',
  },
  loginBody: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  loginHeadingText: {
    fontSize: 20,
    color: 'grey',
    fontWeight: '700',
  },
  loginBody_Item: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textInput: {
    textAlign: 'left',
    color: 'grey',
    fontSize: 11,
    backgroundColor: 'white',
    textAlignVertical: 'center',
    height: 40,
    width: 300,
  },
  Button:{
    width: '100%',
    height: 40,
    backgroundColor: '#303481',
    borderRadius: 5,
  },
  extraOption: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  extraOption_Text:{
     color: 'grey',
     fontSize: 15,
     fontWeight: '600',
  }
})

export default Login
