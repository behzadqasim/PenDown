import React, { useState, useEffect } from 'react'
import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Share,
  Modal
} from 'react-native'


import {TextInput} from "react-native-paper";

import { Searchbar, Text } from 'react-native-paper'
import { useSelector, useDispatch } from 'react-redux';

import { firebase } from "../configuration/firebase/Firebase";

const Home = ({ navigation }) => {

  const dispatch = useDispatch();
  const userLoggedInData = useSelector((state) => { return state.user });

  console.log("LoggedIn User is ", userLoggedInData[0]["name"]);

  const [is_article_fetched, set_is_artiles_fetched] = React.useState(true)

  const [searchQuery, setSearchQuery] = React.useState('')
  const onChangeSearch = query => setSearchQuery(query)

  const [isLiked, set_isLiked] = React.useState(false);

  const categories = ["general", "business", "entertainment", "health", "science", "sports", "technology"];

  const [selectedCategory, setselectedCategory] = React.useState("general");

  const [allarticles, setAllArticles] = React.useState([]);
  const searchBykeyword = () => {
    if (searchQuery.length != 0) {
      set_is_artiles_fetched(false);
      fetch(
        `http://api.mediastack.com/v1/news?access_key=41b571f7139498bc970a3ba83e98a2c9&keywords=${searchQuery}`,
      )
        .then(response => response.json())
        .then(json => {
          if (json["pagination"]["count"] != 0) {
            setAllArticles([]);
            console.log("Fetching articles of keywords ", searchQuery, ". ");
            console.log("Articles is Fetched now.");
            // console.log(json["data"]);
            set_is_artiles_fetched(true);
            setAllArticles(json["data"]);
          }
          else {
            setAllArticles([]);
            set_is_artiles_fetched(true);
            setselectedCategory("general");
            console.log("Articles is not Fetched now because not found.");
            Alert.alert("No Article Found", "Article not found regarding this search text.")

          }


        })
        .catch(error => {
          console.log("Failing to fetch articles.");
          console.log(error);
        })
    }
    else {
      Alert.alert("Search Error", "Please enter the search keyword.")
    }

  }

  const ArticleDisplayBox = (props) => {

    const [is_liked, set_is_liked] = React.useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [comment, setComment] = useState('');

    function genratenewid() {
      return Math.floor(Math.random() * (9999 - 1111 + 1)) + 1111;
    }

    const add_this_article_to_bookmark_ = () => {
      const articleId = genratenewid();
      const articleData = {articleId:articleId ,userid: userLoggedInData[0]["userid"], title: props.article.title, description: props.article.description, isliked: is_liked, comment:comment,author:props.article.author, };
      firebase.database().ref('bookmarks/' + userLoggedInData[0]["userid"] + '/' + articleId).set(articleData)
        .then((response) => {
          console.log("Article added to bookmark successfully.");
          navigation.navigate("Favourite");
          Alert.alert('Done', 'Article added to your bookmark.');
        })
        .catch((error) => {
          Alert.alert(error.message)
        })

    }

    const onShare = async () => {
      try {
        const result = await Share.share({
          title: props.article.title,
          message: props.article.description,
        });
        if (result.action === Share.sharedAction) {
          if (result.activityType) {
            console.log("Shared Allow")
          } else {
            console.log("Not Shared Allow")
          }
        }
      } catch (error) {
        Alert.alert(error.message);
      }
    };

    const date = new Date(props.article.published_at);

    return (
      <View style={styles.centeredView}>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
            setModalVisible(!modalVisible);
          }}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <View style={{ paddingVertical: 15, }}>

                <View style={{ justifyContent: 'center', alignItems: 'center', paddingVertical: 5, }}>
                  {
                    props.article.image !== null ?
                      <Image style={{ width: 350, height: 200, justifyContent: 'center', alignItems: 'center' }} source={{ uri: props.article.image }} /> :
                      <Text style={{ fontSize: 12, fontWeight: 'bold' }}>Image not available</Text>
                  }
                </View>

                <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 5 }}>
                    <Text style={{ fontSize: 14, fontWeight: '800', color: 'grey' }} >👤 {props.article.author}</Text>
                  </View>
                  <View style={{ flex: 1, justifyContent: 'center', paddingVertical: 5 }}>

                    <Text style={{ fontSize: 14, fontWeight: '800', color: 'grey' }} >📅 {date.toLocaleString()}</Text>
                  </View>
                </View>

                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <Text style={{ fontSize: 18, fontWeight: '800' }} >{props.article.title}</Text>
                </View>

                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 5 }}>
                  <Text style={{ textAlign: 'center', paddingHorizontal: 15 , fontSize:16, fontWeight: '600'}}>{props.article.description}</Text>
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TextInput
                    label='Write Comment'
                    mode='outlined'
                    left
                    style={styles.textInput}
                    value={comment}
                    onChangeText={text => setComment(text)}
                  />
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TouchableOpacity onPress={() => { add_this_article_to_bookmark_() }}
                    style={{
                      height: 40,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: 10,
                      paddingVertical: 5,
                      paddingHorizontal: 100,
                      backgroundColor: '#686EE2',
                    }}
                  >
                    <Text style={{ color: '#fff' }} >Post the Comment</Text>
                  </TouchableOpacity>
                </View>

              </View>
              <TouchableOpacity
                style={[styles.button, styles.buttonClose]}
                onPress={() => setModalVisible(!modalVisible)}>
                <Text style={styles.textStyle}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
        <TouchableOpacity style={styles.articleBox} onPress={() => { setModalVisible(true) }} >
          <View style={styles.articleBox_Header}>
            <View style={styles._profileInformation}>
              <Text style={styles._profileInformation_NameText}>
                {props.article.author}
              </Text>
            </View>
            <View style={styles._saveInformation}>
              <TouchableOpacity
                onPress={() => { add_this_article_to_bookmark_() }}
              >
                <Image
                  style={{ height: 25, width: 25 }}
                  source={require('../assets/icons8-favorites-50.png')}
                />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.articleBox_Body}>
            <Text style={styles.articleBox_Body_Heading}>  {props.article.title}</Text>
            <Text style={styles.articleBox_Body_Paragraph}
              numberOfLines={3}
            >
              {props.article.description}
            </Text>
          </View>
          <View style={styles.articleBox_Footer}>
            <TouchableOpacity
              onPress={() => { set_is_liked(!isLiked) }}
            >
              <Image
                style={[
                  styles.articleBox_Footer_Item,
                  {
                    tintColor: is_liked ? 'red' : 'grey',
                  },
                ]}
                source={require('../assets/icons8-filled-heart-64.png')}
              />
            </TouchableOpacity >
            <TouchableOpacity onPress={() => { onShare() }} >
              <Image
                style={styles.articleBox_Footer_Item}
                source={require('../assets/icons8-share-30.png')}
              />
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </View>
    )
  }

  const fetch_articles = async () => {
    set_is_artiles_fetched(false);
    fetch(
      `http://api.mediastack.com/v1/news?access_key=41b571f7139498bc970a3ba83e98a2c9&categories=${selectedCategory}`,
    )
      .then(response => response.json())
      .then(json => {
        console.log("Fetching articles of categories ", selectedCategory, ". ");
        console.log("Articles is Fetched now.");
        // console.log(json["data"]);
        set_is_artiles_fetched(true);
        setAllArticles(json["data"]);

      })
      .catch(error => {
        console.log("Failing to fetch articles.");
        console.log(error);
      })
  }

  useEffect(() => {
    setSearchQuery("");
    fetch_articles()
  }, [selectedCategory])

  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <Searchbar
          placeholder="Search anything ..."
          onChangeText={onChangeSearch}
          value={searchQuery}
          onSubmitEditing={() => { searchBykeyword() }}
        />
      </View>
      <View style={styles.categories}>
        <View style={styles.heading}>
          <Text style={styles.headingText}>Categories</Text>
        </View>
        <View style={styles.categoriesButtonrow}>
          <ScrollView
            horizontal={true}
            showsHorizontalScrollIndicator={false}>
            {categories.map((value, index) => {
              return (
                <TouchableOpacity
                  key={index}
                  style={[styles.categoriesButton, { backgroundColor: value === selectedCategory ? "#690074" : '#9B3284' }]}
                  onPress={() => { setselectedCategory(value) }}
                >
                  <Text style={styles.text_for_categoriesButton} >{value}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>
      </View>
      <View style={styles.searchResult}>
        <View style={styles.heading}>
          <Text style={styles.headingText}>All Articles</Text>
        </View>
        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}>
          {is_article_fetched ? (
            <View>
              {allarticles.map((article, index) => (
                <View key={index}>
                  <ArticleDisplayBox article={article} />
                </View>
              ))}
            </View>
          ) : (
            <View
              style={{
                height: 200,
                marginHorizontal: 10,
                marginVertical: 100,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <ActivityIndicator size='large' color='#1363DF' />
              <Text style={{ fontWeight: '100', marginVertical: 10 }}>
                برائے مہربانی انتظار کریں
              </Text>
            </View>
          )}
        </ScrollView>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 12,
  },
  textInput: {
    textAlign: 'left',
    color: 'grey',
    fontSize: 11,
    backgroundColor: 'white',
    textAlignVertical: 'center',
    height: 40,
    width: 300,
  },
  modalView: {
    marginVertical: 5,
    marginHorizontal:10,
    paddingHorizontal: 60,
    paddingVertical: 100,
    backgroundColor: 'white',
    borderRadius: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inner: {
    padding: 24,
    flex: 1,
    justifyContent: 'space-around',
  },
  articleBody: {
    height: 120,
    paddingHorizontal: 5,
    paddingVertical: 5,
    borderRadius: 12,
    marginVertical: 5,
    marginHorizontal: 1,
    flexDirection: 'row',
    backgroundColor: 'red',
    shadowColor: 'grey',
    shadowOffset: {
      width: 1,
      height: 1,
    },
    shadowOpacity: 1,
    shadowRadius: 1.25,
    elevation: 5,
  },
  articleImageBox: {
    flex: 2,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  articleImage: {
    flex: 1,
    width: '100%',
    borderRadius: 10,
    height: '100%',
    resizeMode: 'contain',
  },
  articleInfoBox: {
    flex: 4,
    paddingHorizontal: 10,
    flexDirection: 'column',
  },
  articleBox: {
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 15,
    marginVertical: 8,
    backgroundColor: '#EEEEEE',
    shadowColor: 'grey',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 1,
    shadowRadius: 0.25,
    elevation: 3,
  },
  articleBox_Header: {
    flex: 1,
    marginVertical: 5,
    flexDirection: 'row',
  },
  _profileInformation_NameText: {
    fontSize: 15,
    marginHorizontal: 10,
    color: '#393E46',
    textAlign: 'left',
    fontStyle: 'normal',
    fontWeight: '600',
  },
  _profileInformation: {
    flex: 3,
    flexDirection: 'row',
    marginHorizontal: 10,
    alignItems: 'center',
  },
  _saveInformation: {
    flex: 1,
    flexDirection: 'row-reverse',
    marginHorizontal: 10,
    alignItems: 'center',
  },
  articleBox_Body: {
    flex: 4,
    marginVertical: 5,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  articleBox_Body_Heading: {
    fontSize: 16,
    color: '#393E46',
    marginHorizontal: 10,
    fontStyle: 'normal',
    textAlign: "center",
    fontWeight: '800',
  },
  articleBox_Body_Paragraph: {
    fontSize: 12,
    color: '#393E46',
    marginHorizontal: 15,
    textAlign: "center",
    marginVertical: 8,
    fontStyle: 'normal',
    fontWeight: '500',
  },
  articleBox_Footer: {
    flex: 1,
    marginVertical: 13,
    marginHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  articleBox_Footer_Item: {
    width: 25,
    height: 25,
    marginEnd: 18,
  },
  container: {
    flex: 1,
    padding: 14,
    flexDirection: 'column',
    marginBottom: 30,
    backgroundColor: 'white',
  },
  profileAndNotification: {
    flex: 1,
    flexDirection: 'row',
  },
  profileButtonBox: {
    flex: 1,
    justifyContent: 'center',
  },
  notificationButtonBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  profileCardLogo: {
    width: 30,
    height: 30,
    borderRadius: 50,
  },
  searchBar: {
    flex: 1,
    alignItems: 'baseline',
    justifyContent: 'center',
  },
  categories: {
    flex: 1,
    marginVertical: 2,
  },
  heading: {
    paddingVertical: 10,
    paddingHorizontal: 10,
    justifyContent: 'center',
  },
  headingText: {
    fontSize: 24,
    color: 'black',
    fontWeight: '800',
  },
  categoriesButtonrow: {
    flexDirection: 'row',
  },
  categoriesButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginHorizontal: 5,
    borderRadius: 20,
  },
  text_for_categoriesButton: {
    color: 'white',
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center'
  },
  searchResult: {
    flex: 10,
    paddingVertical: 20,
  },
})

export default Home
