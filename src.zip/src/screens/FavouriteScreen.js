import React, { useState, useEffect } from 'react';
import {
    StyleSheet,
    View,
    Share,
    Image,
    TouchableOpacity,
    Text,
    SafeAreaView,
    Alert,
    ScrollView,
    Modal,
} from 'react-native'

import {TextInput} from 'react-native-paper';

import RNHTMLtoPDF from 'react-native-html-to-pdf';

import { firebase } from "../configuration/firebase/Firebase";
import { useSelector } from 'react-redux';

const Favourite = ({ navigation }) => {

    const userLoggedInData = useSelector((state) => { return state.user });

    const [all_favourite_article, set_all_favourite_article] = useState([]);

    const [refresh, setrefresh] = useState(false);

    useEffect(() => {
        console.log("Try to Fetching Articles from Firebase");
        const fetchData = async () => {
            const data1Ref = firebase.database().ref('bookmarks/' + userLoggedInData[0]['userid'] + '/');
            console.log("Dataref: ",data1Ref)
            const [data1Snapshot] = await Promise.all([
                data1Ref.once('value'),
            ]);
            const dataArray1 = Object.keys(data1Snapshot.val()).map((key) => ({
                ...data1Snapshot.val()[key],
                id: key,
            }));

            if (dataArray1.length == 0) {
                Alert.alert("No Article", "No Article is Found that is bookmarked.")
                console.log("No articles found")
            }
            else {
                set_all_favourite_article(dataArray1);
                console.log("Articles found")
            }
        };
        fetchData();
    }, [refresh]);


    const ArticleDisplayBox = (props) => {

        const [articleText, setarticleText] = useState(props.description);

        async function createPDF() {
            let options = {
                html: '<h1>' + props.title + '</h1><br><p>' + props.description + '</p>',
                fileName: userLoggedInData[0]['name'] + "articleFile",
                directory: 'Documents',
            };

            let file = await RNHTMLtoPDF.convert(options)
            // console.log(file.filePath);
            Alert.alert("Article Saved", "Your article saved at this location " + file.filePath);
        }
        
        const deletThisArtile = () => {
            
        }


        return (
            <View style={styles.centeredView}>
                <TouchableOpacity style={styles.articleBox} onPress={()=>{setModalVisible(true)}} >
                <View style={styles.articleBox_Header}>
                    <View style={styles._profileInformation}>
                        <Text style={styles._profileInformation_NameText}>
                            {props.author}
                        </Text>
                    </View>
                    <View style={styles._saveInformation}>
                        <Image
                            style={{ height: 25, width: 25, tintColor: 'blue' }}
                            source={require('../assets/icons8-favorites-50.png')}
                        />
                    </View>
                </View>
                <View style={styles.articleBox_Body}>
                    <Text style={styles.articleBox_Body_Heading}>  {props.title}</Text>
                    <Text style={styles.articleBox_Body_Paragraph}
                    >
                        {props.description}
                    </Text>
                </View>
                <View style={styles.articleBox_Footer}>
                    <TouchableOpacity onPress={() => { createPDF() }} >
                        <Image
                            style={styles.articleBox_Footer_Item}
                            source={require('../assets/pdf.png')}
                        />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => { deletThisArtile() }} >
                        <Image
                            style={styles.articleBox_Footer_Item}
                            source={require('../assets/trash-can.png')}
                        />
                    </TouchableOpacity>
                </View>
                </TouchableOpacity>
            </View>
        )
    }

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.headingCampaign}>
                <Text style={styles.headingCampaignHeadingText}>History</Text>
                <TouchableOpacity style={{ width: "50%", backgroundColor: 'skyblue', borderRadius: 5, justifyContent: "center", alignItems: "center", paddingVertical: 5, marginVertical: 5, }}
                    onPress={() => { setrefresh(!refresh) }}
                >
                    <Text>Refresh</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.RideDetailsBox}>
                <View style={{ flex: 1, }}>
                    <ScrollView>
                        {
                            all_favourite_article.map((article, index) => {
                                if (article.userid == userLoggedInData[0]['userid']) {
                                    return (
                                        <ArticleDisplayBox title={article.title} articleID={article.articleId} author={article.author} description={article.description} isliked={article.isliked} key={Math.random()} />
                                    )
                                }

                            })
                        }
                    </ScrollView>
                </View>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        marginHorizontal: 10,
        marginVertical: 10,
        marginBottom: 70
    },
    headingCampaign: {
        flex: 1,
        justifyContent: 'center'
    },
    headingCampaignHeadingText: {
        fontSize: 22,
        fontWeight: 'bold',
        textAlign: 'center'
    },
    RideDetailsBox: {
        flex: 10
    },
    RideRequestBox: {
        width: '100%',
        paddingHorizontal: 20,
        height: 130,
        marginVertical: 5,
        paddingVertical: 10,
        borderRadius: 15,
        backgroundColor: '#334756',
    },
    articleBody: {
        paddingHorizontal: 5,
        paddingVertical: 5,
        borderRadius: 12,
        marginVertical: 5,
        marginHorizontal: 1,
        flexDirection: 'row',
        backgroundColor: 'red',
        shadowColor: 'grey',
        shadowOffset: {
            width: 1,
            height: 1,
        },
        shadowOpacity: 1,
        shadowRadius: 1.25,
        backgroundColor: "white",
        elevation: 5,
    },
    articleImageBox: {
        flex: 2,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    articleImage: {
        flex: 1,
        width: '100%',
        borderRadius: 10,
        height: '100%',
        resizeMode: 'contain',
    },
    articleInfoBox: {
        flex: 4,
        paddingHorizontal: 10,
        flexDirection: 'column',
    },
    articleBox: {
        paddingHorizontal: 15,
        paddingVertical: 10,
        borderRadius: 15,
        marginVertical: 8,
        backgroundColor: '#fff',
        shadowColor: 'grey',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 1,
        shadowRadius: 0.25,
        elevation: 3,
    },
    articleBox_Header: {
        flex: 1,
        marginVertical: 5,
        flexDirection: 'row',
    },
    _profileInformation_NameText: {
        fontSize: 15,
        marginHorizontal: 10,
        color: '#393E46',
        textAlign: 'left',
        fontStyle: 'normal',
        fontWeight: '600',
    },
    _profileInformation: {
        flex: 3,
        flexDirection: 'row',
        marginHorizontal: 10,
        alignItems: 'center',
    },
    _saveInformation: {
        flex: 1,
        flexDirection: 'row-reverse',
        marginHorizontal: 10,
        alignItems: 'center',
    },
    articleBox_Body: {
        flex: 4,
        marginVertical: 5,
        flexDirection: 'column',
        justifyContent: 'center',
    },
    articleBox_Body_Heading: {
        fontSize: 16,
        color: '#393E46',
        marginHorizontal: 10,
        fontStyle: 'normal',
        textAlign: "center",
        fontWeight: '800',
    },
    articleBox_Body_Paragraph: {
        fontSize: 12,
        color: '#393E46',
        marginHorizontal: 15,
        textAlign: "center",
        marginVertical: 8,
        fontStyle: 'normal',
        fontWeight: '500',
    },
    textInput: {
        textAlign: 'left',
        color: 'grey',
        fontSize: 11,
        backgroundColor: 'white',
        textAlignVertical: 'center',
        height: 40,
        width: 300,
      },
    articleBox_Footer: {
        flex: 1,
        marginVertical: 13,
        marginHorizontal: 20,
        flexDirection: 'row',
        alignItems: 'center',
    },
    articleBox_Footer_Item: {
        width: 25,
        height: 25,
        marginEnd: 18,
    },
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 12,
      },
      modalView: {
        marginVertical: 5,
        marginHorizontal:10,
        paddingHorizontal: 60,
        paddingVertical: 100,
        backgroundColor: 'white',
        borderRadius: 20,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
      },
      button: {
        borderRadius: 20,
        padding: 10,
        elevation: 2,
      },
      buttonOpen: {
        backgroundColor: '#F194FF',
      },
      buttonClose: {
        backgroundColor: '#2196F3',
      },
})

export default Favourite;