import React from "react";
import { StyleSheet, View, ScrollView, Alert } from 'react-native'
import { TextInput, Text, Button } from 'react-native-paper'

import { firebase } from "../configuration/firebase/Firebase";

import { useDispatch } from 'react-redux';
import { setLoggedInUser } from '../configuration/store/slice/userSlice';

const Register = ({ navigation }) => {

  const dispatch = useDispatch();

  const [name, setName] = React.useState('')
  const [emailAddress, setemailAddress] = React.useState('')
  const [password, setpassword] = React.useState('')
  const [country, setCountry] = React.useState('')
  const [phoneNumber, setphoneNumber] = React.useState('')
  const [confirmPassword, setconfirmPassword] = React.useState('')

  const registerTheUserNow = async () => {
    if (emailAddress == "" || password == "" || name == "" || country == "" || phoneNumber == "") {
      if (password != confirmPassword) {
        Alert.alert("Error", "Please enter valid password and confirm password.")
      }
      Alert.alert("Error", "Please input all fields.")
    }
    else {
      if (password == confirmPassword) {
        await firebase.auth().createUserWithEmailAndPassword(emailAddress, password)
          .then((data) => {
            console.log(data.user)
            const  user = data.user;
            const userdata = { userid: user.uid, name: name, country: country, phoneNumber: phoneNumber, email: emailAddress, password: password };
            firebase.database().ref('users/' + user.uid).set(userdata)
              .then((response) => {
                console.log(response);
                dispatch(setLoggedInUser(userdata));
                Alert.alert('Congratulations!', 'You are registered successfully')
                navigation.navigate('HomeTabs');
              })
              .catch((error) => {
                console.log(error);
                Alert.alert("Error", error.message)
              });
          })
          .catch((error) => {
            Alert.alert("Error", error.message)
          })
      }
      else{
        Alert.alert('Error!', 'Password didnot matched.')
      }

    }

  }

  return (
    <View style={styles.container}>
      <View style={styles.logoBox}>
        <Text style={styles.logo}>Pen Down</Text>
      </View>
      <View style={styles.loginBody}>
        <View style={styles.loginBody_Item}>
          <Text style={styles.loginHeadingText}>Create your Account.</Text>
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Name'
            mode='outlined'
            left
            style={styles.textInput}
            value={name}
            onChangeText={text => setName(text)}
          />
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Country'
            mode='outlined'
            left
            style={styles.textInput}
            value={country}
            onChangeText={text => setCountry(text)}
          />
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Phone Number'
            mode='outlined'
            left
            style={styles.textInput}
            value={phoneNumber}
            keyboardType="phone-pad"
            onChangeText={text => setphoneNumber(text)}
          />
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Email Address'
            mode='outlined'
            left
            style={styles.textInput}
            value={emailAddress}
            keyboardType="email-address"
            onChangeText={text => setemailAddress(text)}
          />
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Password'
            mode='outlined'
            left
            style={styles.textInput}
            value={password}
            onChangeText={text => setpassword(text)}
            keyboardType="visible-password"
          />
        </View>
        <View style={styles.loginBody_Item}>
          <TextInput
            label='Confirm Password'
            mode='outlined'
            left
            secureTextEntry={true}
            style={styles.textInput}
            keyboardType="visible-password"
            value={confirmPassword}
            onChangeText={text => setconfirmPassword(text)}
          />
        </View>
        <View style={styles.loginBody_Item}>
          <Button
            mode='contained'
            style={styles.Button}
            onPress={() => { registerTheUserNow() }}>
            <Text style={{ color: 'white' }}>Sign Up</Text>
          </Button>
        </View>
      </View>
      <View style={styles.extraOption}>
        <View style={styles.loginBody_Item}>
          <Text style={styles.extraOption_Text}>Already have an Account? <Text style={{ color: '#303481' }}>Sign In</Text></Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  logoBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    fontSize: 50,
    color: '#161D6F',
    letterSpacing: 1,
    fontWeight: '800',
  },
  loginBody: {
    flex: 4,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  loginHeadingText: {
    fontSize: 20,
    color: 'grey',
    fontWeight: '700',
  },
  loginBody_Item: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textInput: {
    textAlign: 'left',
    color: 'grey',
    fontSize: 11,
    backgroundColor: 'white',
    textAlignVertical: 'center',
    height: 40,
    width: 300,
  },
  Button: {
    width: '100%',
    height: 40,
    backgroundColor: '#303481',
    borderRadius: 5,
  },
  extraOption: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  extraOption_Text: {
    color: 'grey',
    fontSize: 15,
    fontWeight: '600',
  }
})

export default Register;