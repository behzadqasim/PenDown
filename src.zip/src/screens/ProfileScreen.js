import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Modal,
  TextInput,
  Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { clearLoggedInUser } from '../configuration/store/slice/userSlice';
import { firebase } from "../configuration/firebase/Firebase";
import { useSelector, useDispatch } from 'react-redux';

const Profile = ({ navigation }) => {

  const dispatch = useDispatch();
  const userLoggedInData = useSelector((state) => { return state.user });
  const [modalVisible, setModalVisible] = useState(false);
  const [refresh, setrefresh] = useState(false);

  console.log("Logged In user : ", userLoggedInData);

  const [name, setname] = useState(userLoggedInData[0]['name']);
  const [country, setcountry] = useState(userLoggedInData[0]['country']);
  const [phoneNumber, setphoneNumber] = useState(userLoggedInData[0]['phoneNumber']);
  const [password, setpassword] = useState(userLoggedInData[0]['password']);
  const [newpassword, setnewpassword] = useState('');

  const LogoutTheAccount = () => {
    const removeValue = async () => {
      try {
        await AsyncStorage.removeItem('@storage_Key')
        console.log("Removed user from local storage.");
      } catch(e) {
       Alert.alert("Error","Error while removing data from ")
      }
    
      console.log('Done.')
    }
    removeValue();
    dispatch(clearLoggedInUser());
    navigation.navigate('Login')
  }

  useEffect(() => {
}, [refresh]);

  async function updateProfile() {
    if(newpassword.length > 6){
      const user = firebase.auth().currentUser;
      console.log(user);
      const credential = firebase.auth.EmailAuthProvider.credential(
        user.email,
        password
      );
      user.reauthenticateWithCredential(credential)
        .then(() => {
          // Update the password
          user.updatePassword(newpassword)
            .then(() => {
              const documentRef = firebase.database().ref("users/" + userLoggedInData[0]['userid']);
              console.log(documentRef);
              documentRef.update({
                name: name,
                country: country,
                phoneNumber: phoneNumber,
                password:newpassword,
              })
                .then(() => {
                  Alert.alert("Profile Updated Successfully.")
                  console.log('Document successfully updated!');
                  setModalVisible(false);
                  setrefresh(!refresh);
          
                })
                .catch((error) => {
                  console.error('Error updating document: ', error);
                });
              Alert.alert('Password updated successfully!');
            })
            .catch((error) => {
              Alert.alert('Error updating password. Please try again.');
            });
        })
        .catch((error) => {
          Alert.alert('Incorrect current password. Please try again.');
        });
    }




  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.porfilePicture}>
        <Image
          source={require('../assets/user2.png')}
          style={{ width: 150, height: 150 }}
        />
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
            setModalVisible(!modalVisible);
          }}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <View style={{ paddingVertical: 15, }}>

                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TextInput
                    style={styles.textInput}
                    value={name}
                    onChangeText={setname}
                  />
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TextInput
                    style={styles.textInput}
                    value={country}
                    onChangeText={setcountry}
                  />
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TextInput
                    style={styles.textInput}
                    value={phoneNumber}
                    onChangeText={setphoneNumber}
                  />
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TextInput
                    style={styles.textInput}
                    value={password}
                    onChangeText={setpassword}
                  />
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TextInput
                    style={styles.textInput}
                    value={newpassword}
                    onChangeText={setnewpassword}
                  />
                </View>
                <View style={{ justifyContent: 'center', alignItems: "center", paddingVertical: 10 }}>
                  <TouchableOpacity onPress={() => { updateProfile() }}
                    style={{
                      height: 40,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: 10,
                      paddingVertical: 5,
                      paddingHorizontal: 100,
                      backgroundColor: '#686EE2',
                    }}
                  >
                    <Text style={{ color: '#fff' }} >Update Profile Now</Text>
                  </TouchableOpacity>
                </View>
              </View>
              <TouchableOpacity
                style={[styles.button, styles.buttonClose]}
                onPress={() => setModalVisible(!modalVisible)}>
                <Text style={styles.textStyle}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
      <View style={styles.porfileInformation}>
        <View style={styles.row}>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>Name</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>{userLoggedInData[0]["name"]}</Text>
          </View>
        </View>
        <View style={styles.row}>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>Country</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>{userLoggedInData[0]["country"]}</Text>
          </View>
        </View>
        <View style={styles.row}>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>Email</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>{userLoggedInData[0]["email"]}</Text>
          </View>
        </View>
        <View style={styles.row}>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>Phone Number</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.porfileInformationText}>{userLoggedInData[0]["phoneNumber"]}</Text>
          </View>
        </View>
      </View>
      <View style={styles.porfileButtons}>
        <TouchableOpacity
          style={styles.BButton}
          onPress={() => { setModalVisible(true)}}
        >
          <Text style={{ color: 'white' }}> Update Profile </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => { LogoutTheAccount() }}
        >
          <Text style={styles.backbuttonText}> Sign Out </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    marginHorizontal: 20,
    marginVertical: 15,
  },
  porfilePicture: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  porfileInformation: {
    flex: 1,
  },
  textInput: {
    textAlign: 'left',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal:10,
    color: 'black',
    fontSize: 14,
    textAlignVertical: 'center',
    height: 40,
    width: 300,
  },
  row: {
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'space-between',
    marginHorizontal: 10,
    marginVertical: 3,
    borderRadius: 10,
    backgroundColor: '#fff'
  },
  col: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  porfileInformationText: {
    fontSize: 18,
    color: 'black',
    fontWeight: '400'
  },
  porfileButtons: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  backButton: {
    backgroundColor: '#fff',
    height: 50,
    width: 300,
    padding: 10,
    marginTop: 20,
    borderRadius: 5,
    borderColor: '#DA0037',
    marginBottom: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30
  },
  BButton: {
    backgroundColor: '#00235B',
    height: 50,
    width: 300,
    padding: 10,
    marginTop: 20,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30
  },
  buttonText: {
    fontSize: 14,
    color: 'white'
  },
  backbuttonText: {
    fontSize: 14,
    color: '#DA0037'
  },
  modalView: {
    marginVertical: 10,
    marginHorizontal: 10,
    paddingHorizontal: 60,
    paddingVertical: 300,
    backgroundColor: 'white',
    borderRadius: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },

})

export default Profile;
