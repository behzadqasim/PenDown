import React from "react";
import { StyleSheet, View,Image } from "react-native";
import {TextInput, Text, Button, } from 'react-native-paper'

const Notification = (state) => {
    return(
        <View style={styles.container}>
            <View style={styles.heading}>
                <Text style={styles.headingText}>Notifications</Text>
            </View>
            <View style={styles.notifications}>

                <View style={styles.notifications_row}>
                    <Text style={styles.notifications_row_Text} >Your account is activated.</Text>
                    <Text style={styles.notifications_row_Text_Time} >Just Now</Text>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 15,
        flexDirection: 'column',
        backgroundColor: 'white',
      },
      heading:{
        flex: 1,
      },
      headingText:{
        fontSize: 18,
        fontWeight: '800',
        textAlign: 'center',
      },
      notifications:{
        flex: 10,
      },
      notifications_row:{
       paddingBottom: 10,
       paddingVertical: 10,
       backgroundColor: '#E4E3E3',
       borderRadius: 10,
       paddingHorizontal: 10,
       marginVertical: 3,
      },
      notifications_row_Text:{
        fontSize: 14,
        color: 'black',
      },
      notifications_row_Text_Time:{
        fontSize: 10,
        color: 'grey',
      },
});

export default Notification;