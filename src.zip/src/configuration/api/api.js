// import axios from 'axios';

// export const api = axios.create({
//     baseURL: 'http://192.168.100.5:5000',
// });

// export const botResponse = async (text) => {
//     console.log(text)
//     const res = await api.post('/get', { msg: text },{headers:{
//         'Content-Type': 'application/json',
//         'Access-Control-Allow-Origin': '*'
//     }});
//     console.log(res.data);
//     return res;
// };

const url = 'https://newsapi.org/v2/everything?q=ai&apiKey=61fa059bb46a47778191e1f3d1ae0880&pageSize=10';