import firebase from 'firebase/compat/app';
import  'firebase/compat/auth';
import  'firebase/compat/database';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDTA2mEu_78v6nTh447mG5XxpV8J5Mtifk",
  authDomain: "pendown-fyp.firebaseapp.com",
  projectId: "pendown-fyp",
  storageBucket: "pendown-fyp.appspot.com",
  messagingSenderId: "1036962028171",
  appId: "1:1036962028171:web:d25a96c4563768dbff128e"
};


if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export { firebase };

