import {createSlice} from "@reduxjs/toolkit";

const userSlice = createSlice({
    name: "LoggedInUser",
    initialState : [],
    reducers : {
        setLoggedInUser(state,action){
            state[0] = action.payload;
        },
        clearLoggedInUser(state,action){
            state = [];
        },
    },

});

export default userSlice.reducer;

//{"country": "Pakistan", "email": "aiman@gmail.com", "name": "Aiman Khan", "password": "12345678", "phoneNumber": "03055392225", "userid": "eNoX9YaaxCbL3NI1F105OamIuus2"}

export const {setLoggedInUser,clearLoggedInUser} = userSlice.actions;