import {createSlice} from "@reduxjs/toolkit";

const newsapiSlice = createSlice({
    name: "newsapikey",
    initialState : "41b571f7139498bc970a3ba83e98a2c9",
    reducers : {
        setnewsapikey(state,action){
            state = action.payload;
        },
    },

});

export default newsapiSlice.reducer;

export const {setnewsapikey} = newsapiSlice.actions;