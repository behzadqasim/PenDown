import { configureStore } from "@reduxjs/toolkit";
import UserSlice from "./slice/userSlice";
import newsapiSlice from "./slice/newsapiSlice";

const store = configureStore({
    reducer:{
        user: UserSlice,
        newsapi:newsapiSlice,
    },
});

export default store;